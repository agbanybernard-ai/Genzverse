const STORAGE_KEY = "genzverse_vibes_demo_v1";
const defaultPosts = [
  {id:"welcome1",author:"GENZVERSE",avatar:"🌈",text:"Welcome to the Vibes Feed! Share a positive thought, ask a fun question or start a friendly conversation. Keep it kind ✨",likes:3,liked:false,comments:[{name:"Vibe Creator",text:"Let's gooo!"}],created:Date.now()-60000}
];
let state = loadState();
let quizIndex = 0;
const questions = [
  {q:"Which planet is known as the Red Planet?",a:["Venus","Mars","Jupiter"],correct:1},
  {q:"How many sides does a hexagon have?",a:["Five","Six","Eight"],correct:1},
  {q:"Which gas do plants take in during photosynthesis?",a:["Oxygen","Nitrogen","Carbon dioxide"],correct:2},
  {q:"What is the capital city of Ghana?",a:["Kumasi","Accra","Tamale"],correct:1}
];
function loadState(){
  try{
    const saved=JSON.parse(localStorage.getItem(STORAGE_KEY));
    if(saved && Array.isArray(saved.posts)) return {...saved, xp:Number(saved.xp)||0, posts:saved.posts};
  }catch(e){}
  return {xp:0,dailyClaimed:false,posts:defaultPosts,likesGiven:0};
}
function saveState(){try{localStorage.setItem(STORAGE_KEY,JSON.stringify(state));}catch(e){showToast("Storage is full. Try removing some posts.");}}
function escapeHTML(value){return String(value).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function showToast(message){const el=document.getElementById("toast");el.textContent=message;el.classList.add("show");clearTimeout(showToast.timer);showToast.timer=setTimeout(()=>el.classList.remove("show"),2200);}
function addXP(amount){state.xp+=amount;saveState();renderStats();}
function renderStats(){
  const level=Math.floor(state.xp/100)+1, progress=state.xp%100;
  document.getElementById("xpCount").textContent=state.xp;
  document.getElementById("xpProfile").textContent=state.xp;
  document.getElementById("levelCount").textContent=level;
  document.getElementById("xpProgress").style.width=progress+"%";
  document.getElementById("dailyBtn").disabled=state.dailyClaimed;
  document.getElementById("dailyBtn").textContent=state.dailyClaimed?"Completed ✓":"Claim 20 XP";
  document.getElementById("postCount").textContent=state.posts.filter(p=>p.author==="You").length;
  document.getElementById("likeCount").textContent=state.likesGiven||0;
}
function goTo(pageId){
  document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id===pageId));
  document.querySelectorAll(".nav-btn").forEach(b=>b.classList.toggle("active",b.dataset.page===pageId));
  window.scrollTo({top:0,behavior:"smooth"});
  if(pageId==="vibesPage") renderFeed();
}
document.querySelectorAll("[data-page]").forEach(b=>b.addEventListener("click",()=>goTo(b.dataset.page)));
document.querySelectorAll("[data-go]").forEach(b=>b.addEventListener("click",()=>goTo(b.dataset.go)));
document.getElementById("dailyBtn").addEventListener("click",()=>{
  if(state.dailyClaimed){showToast("You've already claimed today's mission.");return;}
  state.dailyClaimed=true;addXP(20);showToast("+20 XP collected. Nice work!");
});

const postText=document.getElementById("postText");
postText.addEventListener("input",()=>document.getElementById("charCount").textContent=postText.value.length+"/240");
document.getElementById("postForm").addEventListener("submit",e=>{
  e.preventDefault();const text=postText.value.trim();
  if(!text){showToast("Write something before posting.");return;}
  if(text.length>240){showToast("Keep your post under 240 characters.");return;}
  state.posts.unshift({id:"p"+Date.now()+Math.random().toString(16).slice(2),author:"You",avatar:"✨",text,likes:0,liked:false,comments:[],created:Date.now()});
  postText.value="";document.getElementById("charCount").textContent="0/240";
  addXP(5);renderFeed();showToast("Your post is live on this device! +5 XP");
});
document.getElementById("feedFilter").addEventListener("change",renderFeed);
function timeAgo(time){const mins=Math.max(0,Math.floor((Date.now()-time)/60000));if(mins<1)return "just now";if(mins<60)return mins+"m ago";const hrs=Math.floor(mins/60);if(hrs<24)return hrs+"h ago";return Math.floor(hrs/24)+"d ago";}
function renderFeed(){
  const list=document.getElementById("feedList");let posts=[...state.posts];
  if(document.getElementById("feedFilter").value==="popular")posts.sort((a,b)=>b.likes-a.likes);
  if(!posts.length){list.innerHTML='<div class="empty-state">No posts yet. Start the conversation ✨</div>';return;}
  list.innerHTML=posts.map(p=>`
    <article class="post-card" data-id="${escapeHTML(p.id)}">
      <div class="post-top"><div class="post-avatar">${escapeHTML(p.avatar||"💫")}</div><div><div class="post-author">${escapeHTML(p.author)}</div><div class="post-time">${timeAgo(p.created)}</div></div></div>
      <p class="post-body">${escapeHTML(p.text)}</p>
      <div class="post-actions">
        <button class="action-btn like-btn ${p.liked?"liked":""}" data-action="like">${p.liked?"♥":"♡"} ${p.likes} Like</button>
        <button class="action-btn" data-action="comment">💬 ${p.comments.length} Comment</button>
        ${p.author==="You"?'<button class="action-btn" data-action="delete">🗑 Delete</button>':'<button class="action-btn" data-action="report">⚑ Report</button>'}
      </div>
      <div class="comment-area" id="comments-${escapeHTML(p.id)}">
        <div class="comment-list">${p.comments.length?p.comments.map(c=>`<div class="comment-line"><b>${escapeHTML(c.name)}:</b> ${escapeHTML(c.text)}</div>`).join(""):'<span class="muted">No comments yet. Be the first to say something kind.</span>'}</div>
        <form class="comment-form"><input maxlength="100" aria-label="Write a comment" placeholder="Write a kind comment..." required><button type="submit">Send</button></form>
      </div>
    </article>`).join("");
}
document.getElementById("feedList").addEventListener("click",e=>{
  const btn=e.target.closest("button[data-action]");if(!btn)return;
  const card=btn.closest(".post-card"),post=state.posts.find(p=>p.id===card.dataset.id);if(!post)return;
  const action=btn.dataset.action;
  if(action==="like"){
    post.liked=!post.liked;post.likes=Math.max(0,post.likes+(post.liked?1:-1));
    if(post.liked)state.likesGiven=(state.likesGiven||0)+1;else state.likesGiven=Math.max(0,(state.likesGiven||0)-1);
    saveState();renderFeed();renderStats();
  }else if(action==="comment"){
    document.getElementById("comments-"+CSS.escape(post.id)).classList.toggle("open");
  }else if(action==="delete"){
    if(confirm("Delete your post from this device?")){state.posts=state.posts.filter(p=>p.id!==post.id);saveState();renderFeed();renderStats();showToast("Post deleted.");}
  }else if(action==="report"){
    showToast("Thanks. This demo records no public reports.");
  }
});
document.getElementById("feedList").addEventListener("submit",e=>{
  if(!e.target.matches(".comment-form"))return;e.preventDefault();
  const card=e.target.closest(".post-card"),post=state.posts.find(p=>p.id===card.dataset.id),input=e.target.querySelector("input"),text=input.value.trim();
  if(!post||!text)return;post.comments.push({name:"You",text});saveState();renderFeed();document.getElementById("comments-"+CSS.escape(post.id)).classList.add("open");showToast("Comment added on this device.");
});

function renderQuestion(){
  const q=questions[quizIndex%questions.length];
  document.getElementById("questionNumber").textContent=(quizIndex%questions.length)+1;
  document.getElementById("questionText").textContent=q.q;
  document.getElementById("quizFeedback").textContent="";
  document.getElementById("nextQuestionBtn").classList.add("hidden");
  document.getElementById("answerOptions").innerHTML=q.a.map((a,i)=>`<button class="answer-btn" data-answer="${i}">${escapeHTML(a)}</button>`).join("");
}
document.getElementById("answerOptions").addEventListener("click",e=>{
  const btn=e.target.closest("[data-answer]");if(!btn||btn.disabled)return;
  const q=questions[quizIndex%questions.length],chosen=Number(btn.dataset.answer);
  document.querySelectorAll(".answer-btn").forEach(b=>{b.disabled=true;if(Number(b.dataset.answer)===q.correct)b.classList.add("correct");});
  if(chosen===q.correct){document.getElementById("quizFeedback").textContent="Correct! +10 XP 🎉";addXP(10);}
  else{btn.classList.add("wrong");document.getElementById("quizFeedback").textContent="Not quite. Keep learning — the right answer is highlighted.";}
  document.getElementById("nextQuestionBtn").classList.remove("hidden");
});
document.getElementById("nextQuestionBtn").addEventListener("click",()=>{quizIndex++;renderQuestion();});
document.getElementById("resetBtn").addEventListener("click",()=>{
  if(confirm("This clears your demo XP, posts and activity on this device. Continue?")){
    localStorage.removeItem(STORAGE_KEY);state=loadState();renderStats();renderFeed();showToast("Demo data reset.");
  }
});
renderStats();renderFeed();renderQuestion();
