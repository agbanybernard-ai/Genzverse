GENZVERSE — Acode starter with Vibes Feed

FILES
- index.html
- style.css
- script.js

RUN IN ACODE (ANDROID)
1. Extract this ZIP into a folder named GENZVERSE.
2. Open the GENZVERSE folder in Acode.
3. Open index.html.
4. Use Preview / Run (the webpage preview), NOT the standalone "Run JavaScript" console.
5. If asked, allow the local preview/server to open.

FEATURES
- Home screen and daily 20 XP check-in
- Vibes Feed: create posts, like, comment, sort by latest/popular, delete your own posts, report demo
- Quick quiz with XP rewards
- Profile, level progress, activity counts
- Local device storage using localStorage

IMPORTANT LIMITATION
This is a front-end prototype. Posts, likes, comments and XP are stored only in this browser on this device. They are NOT sent to a server and are NOT visible to other users. Do not use this demo to collect personal information. A real public community needs a secure backend, authentication, privacy controls, moderation/report handling and adult oversight for any accounts or payments.
